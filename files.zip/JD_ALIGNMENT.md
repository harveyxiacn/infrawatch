# InfraWatch — JD 对标分析

## SA – Infrastructure 岗位要求 vs 项目技能展示

| JD 要求 | InfraWatch 中的对应体现 | HR 看到的信号 |
|---------|----------------------|-------------|
| **CS 学位** | 你已有 UPEI CS 学位 | ✅ 已满足 |
| **6年 IT 经验** | Idea IT (3年) + 自由 IT (2年) + AI/系统开发 (4年) | ✅ 已满足 |
| **系统安装与服务器维护** | Server Module: 服务器库存管理、健康监控、安装变更追踪、配置审计 | ✅ 证明你理解系统安装/维护的完整流程 |
| **系统规格文档 (System Specifications)** | System Spec Generator: 自动生成服务器规格文档 PDF，包含硬件配置、OS版本、网络设置 | ✅ 直接展示"produce system specifications"能力 |
| **系统测试 (System Testing)** | Testing Module: 测试用例管理、自动化健康检查（ping/TCP/磁盘）、测试结果 dashboard | ✅ 展示系统测试管理和自动化能力 |
| **虚拟化技术 (Virtualization)** | Virtualization Module: VM 库存、Hypervisor 管理、资源分配报告、容量规划、快照管理 | ✅ 展示对 VMware/KVM/Hyper-V 生态的深入理解 |
| **数据迁移 (Data Migration)** | Migration Module: 项目管理、任务追踪、数据校验（行数/校验和）、回滚规划 | ✅ 完整的数据迁移生命周期管理 |
| **灾备规划 (Disaster Recovery)** | DR Module: DR 计划文档化、RTO/RPO 追踪、DR 演练记录、合规报表 | ✅ 企业级灾备管理能力 |
| **Java 开发** | 整个项目用 Java 17 + Spring Boot 3.2 构建 | ✅ 现代 Java 技术栈 |
| **报表开发** | JasperReports PDF + Apache POI Excel + Quartz 定时报表 | ✅ 企业级报表开发能力 |
| **粤语沟通** | 你粤语母语 | ✅ 已满足 |

---

## 回复 HR 的建议话术

HR 问了你 Java 和报表开发，你可以这样跟进：

> 我最近用 Java 17 + Spring Boot 做了一个基础设施监控和报表平台（InfraWatch），
> 涵盖服务器健康监控、虚拟化管理、数据迁移追踪、灾备管理和自动报表生成。
> 用了 JasperReports 做 PDF 报表、Apache POI 做 Excel 导出、Quartz 做定时任务。
> 项目开源在 GitHub 上，方便您查看代码。

**关键点：** 不要说"我刚做的"，要说"我最近做的一个项目"。让 HR 感觉这是你持续在用的技术。

---

## GitHub 项目展示策略

1. **仓库名:** `infrawatch` — 简洁专业
2. **README:** 有架构图、截图位置、Quick Start — 让 HR 一眼看到项目质量
3. **Commits:** 按模块分阶段提交，展示清晰的开发流程
4. **文档完整:** PRD、技术设计、API 文档、数据库设计、测试计划 — 展示 SA 的文档能力
5. **Docker:** 一键启动 — 展示部署能力

---

## 项目技术亮点（面试可提及）

1. **Flyway 数据库版本管理** — 企业级 schema 管理实践
2. **JasperReports + Apache POI** — 双引擎报表（PDF + Excel），HR 问的正是这个
3. **Spring Security + JWT** — 角色权限控制 + API 安全
4. **Testcontainers** — 用真实 PostgreSQL 跑集成测试
5. **Quartz Scheduler** — 定时报表生成和健康检查
6. **Docker Compose** — 一键部署，展示 DevOps 意识
7. **Thymeleaf + HTMX** — 服务端渲染 + 局部更新，适合内部工具
8. **OpenAPI/Swagger** — API 自文档化
